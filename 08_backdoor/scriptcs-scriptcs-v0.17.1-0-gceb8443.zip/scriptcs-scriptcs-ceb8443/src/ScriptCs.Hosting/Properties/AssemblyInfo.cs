﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("ScriptCs.Hosting")]
[assembly: AssemblyDescription("ScriptCs.Hosting provides common services necessary for hosting scriptcs in your application.")]

[assembly: InternalsVisibleTo("ScriptCs.Hosting.Tests")]