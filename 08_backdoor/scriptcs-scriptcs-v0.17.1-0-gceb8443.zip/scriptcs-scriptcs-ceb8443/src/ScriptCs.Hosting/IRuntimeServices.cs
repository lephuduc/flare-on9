﻿namespace ScriptCs.Hosting
{
    public interface IRuntimeServices
    {
        ScriptServices GetScriptServices();
    }
}