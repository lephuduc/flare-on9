﻿namespace ScriptCs.Contracts
{
    public interface IObjectSerializer
    {
        string Serialize(object value);
    }
}