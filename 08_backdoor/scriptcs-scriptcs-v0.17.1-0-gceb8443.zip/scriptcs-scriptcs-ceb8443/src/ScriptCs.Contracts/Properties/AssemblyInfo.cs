﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ScriptCs.Contracts")]
[assembly: AssemblyDescription("This assembly contains the components necessary to create script packs for scriptcs.")]

[assembly: Guid("a0cbc203-deff-4b7c-b414-11797b7a3100")]
