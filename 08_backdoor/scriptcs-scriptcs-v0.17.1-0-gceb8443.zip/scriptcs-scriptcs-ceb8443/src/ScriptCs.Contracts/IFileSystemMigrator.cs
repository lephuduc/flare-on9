namespace ScriptCs.Contracts
{
    public interface IFileSystemMigrator
    {
        void Migrate();
    }
}
