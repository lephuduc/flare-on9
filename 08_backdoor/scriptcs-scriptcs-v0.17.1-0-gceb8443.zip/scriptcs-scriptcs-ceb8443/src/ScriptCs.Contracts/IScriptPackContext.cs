﻿namespace ScriptCs.Contracts
{
    public interface IScriptPackContext { }
}