﻿using System.Collections.Generic;

namespace ScriptCs.Contracts
{
    public interface IAppDomainAssemblyResolver
    {
        void Initialize();
    }
}