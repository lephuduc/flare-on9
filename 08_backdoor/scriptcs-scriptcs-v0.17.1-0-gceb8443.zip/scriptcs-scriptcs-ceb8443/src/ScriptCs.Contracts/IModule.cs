﻿namespace ScriptCs.Contracts
{
    public interface IModule
    {
        void Initialize(IModuleConfiguration config);
    }
}
