﻿namespace ScriptCs.Engine.Mono.Segmenter
{
    public enum SegmentType
    {
        NotSet = 0,
        Class = 1,
        Prototype = 3,
        Method = 4,
        Evaluation = 5
    }
}