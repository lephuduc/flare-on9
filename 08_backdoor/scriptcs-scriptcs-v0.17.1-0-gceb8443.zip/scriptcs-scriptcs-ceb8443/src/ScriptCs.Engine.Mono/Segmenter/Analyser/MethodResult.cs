﻿namespace ScriptCs.Engine.Mono.Segmenter.Analyser
{
    public class MethodResult
    {
        public string ProtoType { get; set; }

        public string MethodExpression { get; set; }
    }
}
