using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("ScriptCs.Engine.Mono")]
[assembly: AssemblyDescription("ScriptCs.Engine.Mono provides a Mono-based script engine for scriptcs.")]
