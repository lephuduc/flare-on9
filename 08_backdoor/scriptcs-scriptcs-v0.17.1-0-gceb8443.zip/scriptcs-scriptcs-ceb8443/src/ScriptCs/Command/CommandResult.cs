﻿namespace ScriptCs.Command
{
    public enum CommandResult
    {
        Success = 0,
        Error = 1,
    }
}