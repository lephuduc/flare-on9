﻿using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("scriptcs")]
[assembly: AssemblyDescription("scriptcs command line tool.")]

[assembly: Guid("f624ee58-910a-4541-a46f-afcd3edca9df")]

[assembly: NeutralResourcesLanguage("en-US")]

[assembly: InternalsVisibleTo("ScriptCs.Tests")]
