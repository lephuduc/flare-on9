﻿using System.Reflection;

[assembly: AssemblyTitle("ScriptCs.Engine.Roslyn")]
[assembly: AssemblyDescription(
    "ScriptCs.Engine.Roslyn provides a Microsoft.CodeAnalysis-based C# script engine for scriptcs.")]
