using System;
using System.Reflection;

namespace ScriptCs
{
    public class AssemblyInfo
    {
        public string Path { get; set; }
        public Assembly Assembly { get; set; }
        public Version Version { get; set; }
    }
}