﻿using System.Reflection;

[assembly: AssemblyTitle("ScriptCs.Hosting.Tests")]
[assembly: AssemblyDescription("")]
