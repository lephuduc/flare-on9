﻿using System.Reflection;

[assembly: AssemblyTitle("ScriptCs.Engine.Roslyn")]
[assembly: AssemblyDescription("")]
