﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ScriptCs.Tests")]
[assembly: AssemblyDescription("")]

[assembly: Guid("96733f0d-6fa4-4f6d-8f69-e4718eaf48b7")]
