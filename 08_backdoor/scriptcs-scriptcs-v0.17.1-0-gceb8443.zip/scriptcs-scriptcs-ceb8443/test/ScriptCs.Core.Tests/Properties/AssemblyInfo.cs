﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("ScriptCs.Core.Tests")]
[assembly: AssemblyDescription("")]

[assembly: Guid("fe718b7f-5fb4-43eb-a3da-26a1d25e644c")]
