using System.Reflection;

/**
 * Do not manually edit this file. The build script will generate and insert the proper version numbers based on the 
 * contents of 'build\ScriptCs.Version.props'.
 **/

[assembly: AssemblyVersion("0.0.0")]
[assembly: AssemblyInformationalVersion("0.0.0")]